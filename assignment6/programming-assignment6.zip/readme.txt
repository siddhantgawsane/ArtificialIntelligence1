ASSIGNMENT 6 : Decision Trees
NAME: Siddhant Gawsane
UTA ID: 1001231597
LANGUAGE: Python
CODE STRUCTURE:
	Actions are broken down into methods which are logically grouped into classes

COMPILATION AND EXECUTION:
	Run command
	python dtree.py <training_file> <test_file> <optimized/randomized/forestN>
	
	for example:
	python dtree.py pendigits_training.txt pendigits_test.txt optimized
	
	python dtree.py satellite_training.txt satellite_test.txt randomized
	
	python dtree.py yeast_training.txt yeast_test.txt forest15
	
	The program pauses after creating a decision tree, press 'n' to exit or anything else to continue testing the tree for accuracy

