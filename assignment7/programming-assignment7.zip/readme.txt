ASSIGNMENT 7 : Bayesian Classifiers
NAME: Siddhant Gawsane
UTA ID: 1001231597
LANGUAGE: Python
CODE STRUCTURE:
	Actions are broken down into methods which are logically grouped into classes

COMPILATION AND EXECUTION:
	Run command
	python naive_bayes.py <training_file> <test_file> <histograms/gaussians/mixtures> <no. of bins/no. of gaussians>
	
	for example:
	python naive_bayes.py pendigits_training.txt pendigits_test.txt histograms 4
	
	python naive_bayes.py satellite_training_adj.txt satellite_test_adj.txt gaussians
	
	python naive_bayes.py yeast_training_adj.txt yeast_test_adj.txt mixtures 5
